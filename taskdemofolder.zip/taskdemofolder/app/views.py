
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response

from django_celery_beat.models import PeriodicTask
# from django_celery_beat.
from .serlizer import PeriodicTaskSerializer
from .tasks import print_hello

class Demo(APIView):

    def get(self, *args, **kwargs):
        print_hello.delay()
        return Response()

class PeriodicTaskModelViewSet(ModelViewSet):
    queryset = PeriodicTask.objects.all()
    serializer_class = PeriodicTaskSerializer
